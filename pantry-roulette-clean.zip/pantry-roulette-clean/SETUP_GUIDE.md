# 🚀 Quick Setup Guide for Pantry Roulette

## Upload to GitHub

### Method 1: Via GitHub Web Interface (Easiest)

1. **Go to your repository**: https://github.com/shronit94/pantry-roulette-
2. **Drag and drop** all the files from this folder to the repository
3. **Commit** the changes

### Method 2: Via Command Line

```bash
# Navigate to this folder
cd pantry-roulette-clean

# Initialize git
git init
git branch -M main

# Add all files
git add .

# Commit
git commit -m "Initial commit: Pantry Roulette app"

# Add remote
git remote add origin https://github.com/shronit94/pantry-roulette-.git

# Push
git push -u origin main
```

## After Upload

### 1. Install Dependencies
```bash
npm install
```

### 2. Set Up API Credentials

Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

Get your free Edamam API credentials:
- Visit: https://developer.edamam.com/
- Sign up and subscribe to "Recipe Search API" (free tier)
- Copy your App ID and App Key
- Add them to `.env`:
  ```
  VITE_EDAMAM_APP_ID=your_app_id_here
  VITE_EDAMAM_APP_KEY=your_app_key_here
  ```

### 3. Run the App

```bash
# Development mode
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## What's Included

✅ Complete Pantry Roulette app with burgundy theme
✅ 7 React components (Header, BottomNav, IngredientPicker, MagicRoulette, RecipeCard, AITip, LoadingSkeleton)
✅ Glassmorphism design with mesh gradient background
✅ Material Symbols icons
✅ Framer Motion animations
✅ Edamam API integration
✅ Confetti celebration effects

## Features

- 🎨 Premium dark mode with burgundy (#a72f3d) theme
- 👨‍🍳 "Bonjour, Chef" greeting header
- 🎰 Circular roulette spin button
- 🔍 Live recipe search with Edamam API
- 💡 AI-powered lazy cooking tips
- 🎉 Confetti celebration on recipe found
- 📱 Mobile-first responsive design

Enjoy cooking with Pantry Roulette! 🍳
